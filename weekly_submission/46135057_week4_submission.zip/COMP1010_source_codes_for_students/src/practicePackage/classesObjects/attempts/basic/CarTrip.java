package practicePackage.classesObjects.attempts.basic;

public class CarTrip {//done -4
	public double distance, time; //in kms and hours respectively
	
	/**
	 * 
	 * @param d: value meant for distance
	 * @param t: value meant for time
	 * 
	 * assign the higher of 0 and d into distance
	 * assign the higher of 0 and t into time
	 */
	public CarTrip(double d, double t) {
		if(d<0) {
			d=0;
		}
		if(t<0) {
			t=0;
		}
		distance=d;
		time=t;
	}
	
	public double averageSpeed() {
		return distance*1.0/time; //to be completed
	}
	
	/**
	 * return details in the format "distance kms travelled in time hours"
	 * For example, if distance = 2.5, time = 1.2, return "2.5 kms travelled in 1.2 hours" 
	 */
	public String toString() {
		return distance+" kms travelled in "+time+" hours"; //to be completed
		
	}
	
	/**
	 * 
	 * @param other
	 * @return 1 if calling object distance is more than parameter object distance
	 * -1 if calling object distance is less than parameter object distance
	 * 0 if calling object distance is equal to parameter object distance
	 */
	public int compareTo(CarTrip other) {
		if(other.distance<this.distance) {
			return 1;
		}
		else if(other.distance>this.distance) {
			return -1;
		}
		else {
			return 0;
		}
	}
}
