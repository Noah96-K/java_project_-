// Cannot use Math library functions for any task

package practicePackage.introduction.attempts;

public class Stage2 {
	/**
	 * 
	 * @param a
	 * @param b
	 * @param c
	 * @return true if exactly two out of the three values are the same, false otherwise
	 */
	public boolean twoOutOfThree(int a, int b, int c) {
		if(a==b&&a!=c) {
			return true;//complete9
		}
		else if(a==c&&a!=b) {
			return true;
		}
		else if(b==c&&b!=a) {
			return true;
		}
		else
			return false;
	}

	/**
	 * 
	 * @param n (n could be positive, negative or zero)
	 * @return the last digit of the number
	 * For example,
	 * lastDigit(15) = 1
	 * lastDigit(-15) = 5
	 * lastDigit(0) = 0
	 * lastDigit(8) = 8
	 */
	public int lastDigit(int n) {
		if (n>=0) {
			return n%10;
		}
		else
		  return -(n%10); //complete 10
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return the average of the two integers passed.
	 * for example,
	 * average(5, 9) = 7 (or 7.0)
	 * average(5, 8) = 6.5
	 */
	public double average(int a, int b) {
		return ((double)a+(double)b)/2; //complete 11
	}

	/**
	 * 
	 * @param n
	 * @return the absolute value for n.
	 * absolute value is defined as the number without the negative sign, if any
	 * For example, absolute(-6) = 6, absolute(9) = 9
	 */
	public int absolute(int n) {
		if(n>=0) {
			return n;
		}
		else
			return -n;//complete12
	}

	/**
	 * 
	 * @param val
	 * @param low
	 * @param high (assume low is less than or equal to high)
	 * @return value val constrained between low and high.
	 * that is,
	 * 
	 * if val is less than low, return low
	 * if val is more than high, return high
	 * in all other cases, return val
	 */
	public int constrain(int val, int low, int high) {
		 //complete13
		if(val<low) {
			return low;
		}
		else if(high<val) {
			return high;
		}
		else {
			return val;
		}
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @return the quadrant in which coordinate (x, y) exists
	 * quadrant 1: non-negative x, non-negative y
	 * quadrant 2: negative x, non-negative y
	 * quadrant 3: negative x, negative y
	 * quadrant 4: non-negative x, negative y
	 * 
	 */
	public int getQuadrant(int x, int y) {
		if(x>=0) {
			if(y>=0){
				return 1;//complete14
			}
			else
				return 4;
		}
		else {
			if(y>=0) {
				return 2;
			}
			else
				return 3;
		}
	}

	/**
	 * 
	 * @param val (assume val is more than or equal to zero)
	 * @return val rounded to the nearest integer.
	 */
	public int roundOff(double val) {
		if(val>=0) {
			return (int)(val+0.5);//complete 15
		}
		else
			return (int)(val-0.5);
	}

	/**
	 * @param val (assume val is more than or equal to zero)
	 * @return floor of val
	 * floor of a floating-point value is defined as the highest integer
	 * that is less than or equal to the value.
	 * For example, floor(4.2) = 4, floor(7.0) = 7, floor(5.9999) = 5
	 */
	public int floor(double val) {
		if(val>=0) {
			return (int)val;
		}
		else {
			if((int)val==val) {
				return (int)val;
			}
			else
			  return (int)(val-1);
		}
		 //complete 16
	}

	/**
	 * 
	 * @param val (assume val is more than or equal to zero)
	 * @return ceiling of val
	 * ceiling of a floating-point value is defined as the smallest integer
	 * that is more than or equal to the value.
	 * For example, ceiling(4.2) = 5, ceiling(7.0) = 7,
	 * ceiling(5.9999) = 6, ceiling(-3.7) = -3
	 */
	public int ceiling(double val) {
		if(val>=0) {
			if((int)val==val) {
				return (int)val;
			}
			else
			  return (int)(val+1);//complete 17
		}
		else {
			return (int)(val);
		}
	}
}
