package practicePackage.introduction.attempts;

public class Stage1 {
	/**
	 * 
	 * @param n
	 * @return square of n
	 */
	public int square(int n) {
		return n*n; //complete1
	}

	/**
	 * 
	 * @param n (assume n >= 0)
	 * @return the 
	 */
	public int lastDigit(int n) {
//		System.out.println(n%10);
		return n%10; //complete2
	}

	/**
	 * 
	 * @param n
	 * @return true if n is positive (more than 0), false otherwise
	 */
	public boolean isPositive(int n) {
		if(n>0) {
			return true;//complete3
		}
		else {
			return false;
			
		}
	}	

	/**
	 * 
	 * @param n
	 * @return true if n is even (divisible by 2), false otherwise
	 */
	public boolean isEven(int n) {
		if(n%2==0) {
			return true;//complete4
		}
		else
			return false;
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return higher of the two integers passed
	 */
	public int higher(int a, int b) {
		if(a>=b) {
			return a;//complete5
		}
		else {
			return b;
		}
		
	}

	/**
	 * assumption: one of the two values passed is even, other is odd
	 * 
	 * @param a
	 * @param b
	 * @return the value that is even
	 */
	public int evenOne(int a, int b) {
		if(a%2==0) {
			return a;//complete6
		}
		else if(b%2==0){
			return b;
		}
		else {
			return 0;
		}
	}

	/**
	 * 
	 * @param n
	 * @param low
	 * @param high (assume low is less than or equal to high)
	 * @return true if n is in the range [low...high], false otherwise
	 */
	public boolean isInRange(int n, int low, int high) {
		if(n>=low&&n<=high) {
			return true;//complete7
		}
		else
			return false;
	}

	/**
	 * DO NOT use Math library
	 * @param a
	 * @param b
	 * @param c
	 * @return the highest of the three integers passed
	 */
	public int highest(int a, int b, int c) {
		if(a>=b&&a>=c) {
			return a;//complete8
		}
		else if(b>=a&&b>=c) {
			return b;
		}
		else {
			return c;
		}
	}
}
