package comp1010week05submission;

public class TrainingStats {
	public int[] heartRate; //heart rate over the training sessions 
	public int[] decisionMaking; //scores out of 100 for each decision made
	
	/**
	 * create instance copies of parameter arrays int corresponding instance variable arrays
	 * for decision making, constraint all values between 0 and 100
	 * (think about what that means and if you don't understand it, look at the sample output provided)
	 * @param rate
	 * @param decisions
	 */
	public TrainingStats(int[] rate, int[] decisions) {
		heartRate= new int[rate.length];
		decisionMaking=new int[decisions.length];
		for(int i=0;i<rate.length;i++) {
		
			this.heartRate[i]= rate[i];
			}
		for(int k=0;k<decisions.length;k++) {
			if(decisions[k]<0) {
				decisions[k]=0;
				this.decisionMaking[k]=decisions[k];
			}
			else if(decisions[k]>100) {
				decisions[k]=100;
				this.decisionMaking[k]=decisions[k];
			}
			this.decisionMaking[k]=decisions[k];
		}
		
	}
	
	public String toString() {
		String result="HeartRate: [";
		for(int i=0; i<heartRate.length;i++) {
			if(i==heartRate.length-1) {
				result+=heartRate[i]+"] \n";
			}
			else {
			result+=heartRate[i]+",";
			}
		}
		result+="DecisionMaking:[ ";
		for(int k=0;k<decisionMaking.length;k++) {
			if(k==decisionMaking.length-1) {
				result+=decisionMaking[k]+"] \n";
			}
			else {
			result+=decisionMaking[k]+",";}
		}
		return result;
	}
	/**
	 * P/CR level
	 * @return the average heart rate
	 */
	public double averageDecisionAccuracy() {
		double sum=0;
		for(int i=0;i<decisionMaking.length;i++) {
			sum+=decisionMaking[i];
		}
		return sum/decisionMaking.length;
	}
	
	/**
	 * D/HD level
	 * @param n (assume n is between 1 and heartRate.length
	 * @return a sub-array  of size n with the lowest total of heart rate 
	 */
	public int[] bestHeartRateRun(int n) {
		int[] result=new int[n];
		int low=212938;
		int num=0;
		for( int i=0;i<heartRate.length-n;i++) {
			int com=0;
			for(int k=0;k<n;k++) {
				
				com+=heartRate[i+k];
			}
			if(low>com) {
				low=com;
				num=i;
			}
			else {
				continue;
			}
		}
		for(int j=0;j<n;j++) {
			result[j]=heartRate[num+j];
		}
		return result;
	}
	public String toto(int[] re) {
		String result="Best heart rate over"+re.length+"consecutive measurements: [";
		for(int i=0;i<re.length;i++) {
			if(i==re.length-1) {
				result+=re[i]+"] \n";
			}
			else {
			result+=re[i]+",";}
		}
		return result;
	}
}
