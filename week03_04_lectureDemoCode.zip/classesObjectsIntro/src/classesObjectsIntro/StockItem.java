package classesObjectsIntro;

public class StockItem {
	public String itemName;
	public String category;
	public double unitPrice;
	public int quantity;
}
