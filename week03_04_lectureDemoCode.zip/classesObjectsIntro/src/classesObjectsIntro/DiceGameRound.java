package classesObjectsIntro;

import java.util.Arrays;

/**
 * 
 * @author mq40478890
 * n players roll the die k times each
 * whoever gets the highest average wins
 * 3 players, 4 rolls
 * {6, 1, 3, 4}
 * {5, 5, 6, 6}: winner
 * {1, 1, 1, 1}
 */
public class DiceGameRound {
	public DiceRollRun[] players;
	
	/**
	 * 
	 * @param n: number of players
	 * @param k: number of times each player gets to roll the dice
	 */
	public DiceGameRound(int n, int k) {
		players = new DiceRollRun[Math.max(2, n)];
		for(int i=0; i < players.length; i++) {
			players[i] = new DiceRollRun(k);
		}
	}
	
	public int winner() {
		int currentWinnerIndex = 0; //assume first player is the winner
		for(int i=1; i < players.length; i++) {
			double winnerAverage = players[currentWinnerIndex].average();
			double currentItemAverage = players[i].average();
			if(currentItemAverage > winnerAverage) {
				currentWinnerIndex = i;
			}
		}
		return currentWinnerIndex;
	}
	
	public int[] winners() {
		//PHASE 1: determine size of array to be returned
		int currentWinnerIndex = 0; //assume first player is the winner
		int nPlayersTied = 1;
		for(int i=1; i < players.length; i++) {
			double winnerAverage = players[currentWinnerIndex].average();
			double currentItemAverage = players[i].average();
			if(currentItemAverage > winnerAverage) {
				currentWinnerIndex = i;
				nPlayersTied = 1; //new winner
			}
			else if(currentItemAverage == winnerAverage) { //another player with the same score
				nPlayersTied++; //another winner
			}
		}

		//PHASE 2: Create and populate the required arrays
		int[] result = new int[nPlayersTied];
		
		nPlayersTied = 1;
		int k = 0; //index where next tied player index should be put
		for(int i=1; i < players.length; i++) {
			double winnerAverage = players[currentWinnerIndex].average();
			double currentItemAverage = players[i].average();
			if(currentItemAverage == winnerAverage) { 
				result[k] = i;
				k++; //next time, put the item in the next slot
			}
		}
		return result;
	}
	
	public String toString() {
		String result = "";
		for(int i=0; i < players.length; i++) {
			result += "Player at index "+i+": "+players[i].toString()+"\n";
		}
		return result + "Winner: Player(s) at index "+Arrays.toString(winners());
	}
}
