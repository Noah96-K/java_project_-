package classesObjectsIntro;

public class DiceGameRoundClient {

	public static void main(String[] args) {
		DiceGameRound singleRoundGame = new DiceGameRound(40, 2);
		System.out.println(singleRoundGame);
	}

}
