package classesObjectsIntro;

public class DiceGame {
	public DiceGameRound[] rounds;
	
	public DiceGame(int r, int n, int k) {
		rounds = new DiceGameRound[Math.max(1, r)];
		for(int i=0; i < rounds.length; i++) {
			rounds[i] = new DiceGameRound(n, k);
		}
	}
	
	public String toString() {
		String result = "";
		int[] winCounts = new int[rounds[0].players.length];
		for(int i=0; i < rounds.length; i++) {
			int[] roundWinners = rounds[i].winners();
			for(int k=0; k < roundWinners.length; k++) {
				winCounts[roundWinners[k]]++;
			}
			result+=rounds[i].toString()+"\n";
		}
		result+="Number of times each player won:\n";
		for(int i=0; i < winCounts.length; i++) {
			result+="Player at index "+i+": "+winCounts[i]+"\n";
		}
		return result;
	}
	
}
