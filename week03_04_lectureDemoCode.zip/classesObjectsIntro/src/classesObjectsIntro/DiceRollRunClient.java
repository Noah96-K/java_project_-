package classesObjectsIntro;

public class DiceRollRunClient {
	public static void main(String[] args) {
		DiceRollRun player1 = new DiceRollRun(5);
//		int count = 1;
//		while(player1.perfectRun() == false) {
//			System.out.println(count+". "+player1);
//			player1 = new DiceRollRun(5);
//			count++;
//		}
//		System.out.println("Took "+count+" iterations");
		System.out.println(player1);
	}
}
