package classesObjectsIntro;

public class Line {
	public Point start, end;
	public Line(Point p1, Point p2) {
		start = new Point(p1);
		end = new Point(p2);
	}
	
	public boolean isVertical() {
		return start.x == end.x;
	}
	
	public boolean isHorizontal() {
		return start.y == end.y;
	}
	
	public double length() {
		double dx = end.x - start.x;
		double dy = end.y - start.y;
		double ss = dx*dx + dy*dy;
		double result = Math.sqrt(ss);
		return result;
	}
	
	public String toString() {
		return start + " - " + end;
	}
}