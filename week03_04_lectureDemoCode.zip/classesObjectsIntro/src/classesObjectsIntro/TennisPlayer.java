package classesObjectsIntro;

public class TennisPlayer {
	public String name;
	public int seeding;
	
	public TennisPlayer(String str, int seed) {
		name = str;
		if(seed < 1) {
			seeding = 1;
		}
		else {
			if(seed > 32) {
				seeding = 32;
			}
			else {
				seeding = seed;
			}
		}
	}
	
	public String toString() {
		return name + " ("+seeding+")";
	}
}
