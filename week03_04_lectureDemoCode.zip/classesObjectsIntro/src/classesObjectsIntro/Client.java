package classesObjectsIntro;

public class Client {

	public static void main(String[] args) {
//		Point p = new Point(10,40);
//		Point q = new Point(70,60);
//		Line line = new Line(p, q);
//		System.out.println("Length: "+line.length());
//		
//		TennisPlayer p1 = new TennisPlayer("Federer", 1);
//		TennisPlayer p2 = new TennisPlayer("Nadal", 4);
//		TennisMatch wimbledonFinal = new TennisMatch(p1, p2);
//		System.out.println(wimbledonFinal);
		
		//array of Rectangle objects
		Rectangle[] boxes = new Rectangle[3];
		for(int i=0; i < boxes.length; i++) {
			//instantiate item at index i before displaying
			double w = (20 + (int)(Math.random()*141))/10.0; 
			double h = (28 + (int)(Math.random()*23))/5.0; 
			boxes[i] = new Rectangle(w, h);
			System.out.println("Rectangle at index "+i+": "+boxes[i]);
		}
		
		
		
//		Line[] art = new Line[5];
//		for(int i=0; i < art.length; i++) {
//			art[i] = new Line(new Point(i, i), new Point(i+1, i+1));
//			System.out.println(art[i]);
//		}
	}

}
