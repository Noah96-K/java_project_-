package classesObjectsIntro;

public class DiceGameClient {

	public static void main(String[] args) {
		DiceGame game = new DiceGame(10000, 4, 3);
		System.out.println(game);
	}

}
