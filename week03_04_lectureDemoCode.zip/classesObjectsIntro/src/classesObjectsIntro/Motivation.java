package classesObjectsIntro;

public class Motivation {
	public static void main(String[] whatever) {
		double x, y, spdX, spdY, dia;
		x = (int)(Math.random()*100);
		y = (int)(Math.random()*100);
		spdX = Math.random()*2;
		spdY = Math.random()*2;
		dia = 20 + (int)(Math.random()*31);
		
		double x2, y2, spdX2, spdY2, dia2;
		x2 = (int)(Math.random()*100);
		y2 = (int)(Math.random()*100);
		spdX2 = Math.random()*2;
		spdY2 = Math.random()*2;
		dia2 = 20 + (int)(Math.random()*31);
		System.out.println("First circle: diameter "+dia+" at location ("+x+", "+y+") \nis travelling at the speed of ("+spdX+", "+spdY+")");
		System.out.println("Second circle: diameter "+dia2+" at location ("+x2+", "+y2+") \nis travelling at the speed of ("+spdX2+", "+spdY2+")");
	}
	
	public static double[] getNextLoc(double curX, double curY, double spdX, double spdY) {
		return new double[2]; //x, y
	}

	public static double[] getNextLoc(MovingCircle circle) {
		return new double[2]; //x, y
	}
		
	
	
}
