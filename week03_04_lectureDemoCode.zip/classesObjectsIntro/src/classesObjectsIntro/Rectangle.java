package classesObjectsIntro;

public class Rectangle {
	//instance variables
	public double width, height;
	
	
	public Rectangle(double w, double h) {
		width = w;
		height = h;
	}
	
	public Rectangle(double side) {
		width = side;
		height = side;
	}

	public Rectangle() { //default constructor
		width = 1;
		height = 1;
	}
	
//	public String toString() {
//		return width + " by " + height;
//	}
	
	//calculate area on an as-you-need basis

	//static
	//operate on the parameters passed
	
	//non-static (instance method)
	//operate on the object on which 
	//they are called
	public double area() {
		double result = width * height;
		return result;
	}
	
	/**
	 * ref. copy of calling object is made into this
	 * ref. copy of parameter object is made into other
	 * 
	 * @param other
	 * @return 1 if calling object is "greater than" parameter object
	 * -1 if calling object is "lesser than" parameter object
	 * 0 if calling object and parameter object are "equal"
	 * 
	 * what defines the order??? for rectangles 
	 */
	public int compareTo(Rectangle other) {
		double a1 = area(); //by default, it's called on "this"
		double a2 = other.area();
		if(a1 > a2) {
			return 1;
		}
		if(a1 < a2) {
			return -1;
		}
		return 0;
	}
	
	public String toString() {
		return width + " by " + height;
	}
}
