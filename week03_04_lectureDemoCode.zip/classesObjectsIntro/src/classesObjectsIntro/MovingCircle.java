package classesObjectsIntro;

public class MovingCircle {
	public double x, y, spdX, spdY, dia;
}
