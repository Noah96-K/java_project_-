package classesObjectsIntro;

/**
 * 
 * @author mq40478890
 * a fixed of dice rolls 
 * normal 6-faced die
 */
public class DiceRollRun {
	public int[] outcomes;

	public DiceRollRun(int n) {
		if(n <= 1) {
			n = 1; //roll at least once
		}
		//guaranteed that n >= 1
		outcomes = new int[n];
		for(int i=0; i < outcomes.length; i++) {
			outcomes[i] = 1 + (int)(Math.random()*6);
		}
	}

	public double average() {
		int total = 0;
		for(int i=0; i < outcomes.length; i++) {
			total+=outcomes[i];
		}
		return ((double)total)/outcomes.length;
	}

	public boolean perfectRun() {
		for(int i=0; i < outcomes.length; i++) {
			if(outcomes[i] != 6) {
				return false;
			}
		}
		return true;
	}

	public String toString() {
		String result = "[";
		for(int i=0; i < outcomes.length; i++) {
			result += outcomes[i];
			if(i < outcomes.length - 1) { //for all but last item
				result += ", ";
			}
		}
		return result + "] Average: "+average();
	}
}
