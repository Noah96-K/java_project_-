package classesObjectsIntro;

public class TennisMatch {
	public TennisPlayer player1, player2;
	
	public TennisMatch(TennisPlayer a, TennisPlayer b) {
		player1 = a;
		player2 = b;
	}
	
	public String toString() {
		return player1 + " vs. " + player2;
	}
}
