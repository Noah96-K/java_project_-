package classesObjectsIntro;

public class BadReferenceCopy {

	public static void main(String[] args) {
		Point p = new Point(10, 40);
		Point q = new Point(70, 60);
		Line line = new Line(p, q); //line to be populated with p, q
		System.out.println(line);
		
		//later on ....
		
		p.x = 50;
		
		System.out.println(line);
	}

}
