package classesObjectsIntro;

public class Point {
	public int x, y;
	
	public Point(int _x, int _y) {
		x = _x;
		y = _y;
	}
	
	/**
	 * COPY CONSTRUCTOR
	 * Used to make an instance copy of the parameter object
	 * @param source
	 */
	public Point(Point source) {
		x = source.x;
		y = source.y;
	}
	
	public String toString() {
		return "("+x+","+y+")";
	}
}