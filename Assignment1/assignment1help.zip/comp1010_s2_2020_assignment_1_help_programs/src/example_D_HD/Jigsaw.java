package example_D_HD;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Jigsaw {
	public static char[][] letters;
	public static String[] words;

	public static void read(String filename) throws FileNotFoundException {
		Scanner scanner = new Scanner(new FileReader(filename));
		int rows = 0;
		int columns = 0;
		while(scanner.hasNextLine()) {
			columns = scanner.nextLine().length();
			rows++;
		}
		letters = new char[rows][columns];

		scanner = new Scanner(new FileReader(filename));
		for(int i=0; i < letters.length; i++) {
			String line = scanner.nextLine();
			for(int k=0; k < line.length(); k++) {
				letters[i][k] = line.charAt(k);
			}
		}
	}

	public static int[] getLocation(String target) {
		int[] start = getLocation(target.charAt(0), 0, 0);
		while(start!=null) {
			int startRow = start[0];
			int startColumn = start[1];
			if(startRow <= letters.length - target.length()) { //can check down
				boolean eliminate = false;
				for(int i=1; i < target.length() && !eliminate; i++) {
					if(letters[startRow+i][startColumn] != target.charAt(i)) {
						eliminate = true;
					}
				}
				if(!eliminate) {
					return new int[] {startRow,startColumn,0};
				}
			}
			if(startColumn <= letters[startRow].length - target.length()) { //can check down
				boolean eliminate = false;
				for(int i=1; i < target.length() && !eliminate; i++) {
					if(letters[startRow][startColumn+i] != target.charAt(i)) {
						eliminate = true;
					}
				}
				if(!eliminate) {
					return new int[] {startRow,startColumn,1};
				}
			}
			if(startColumn < letters[startRow].length - 1) {						
				start = getLocation(target.charAt(0), startRow, startColumn+1);
			}
			else if(startRow < letters.length - 1) {
				start = getLocation(target.charAt(0), startRow+1, 0);
			}
		}
		return null;
	}

	public static int[] getLocation(char letter, int startRow, int startColumn) {
		for(int i=startRow; i < letters.length; i++) {
			int k = 0;
			if(i==startRow) {
				k = startColumn;
			}
			for(; k < letters[i].length; k++) {
				//System.out.println("check "+i+", "+k+" for "+letter+". Letter at location is "+letters[i][k]);
				if(letters[i][k] == letter) {
					//System.out.println(letter+" found at "+i+", "+k);
					return new int[] {i, k};
				}
			}
		}
		return null;
	}

	public static void main(String[] args) throws FileNotFoundException {
		read("advanced.csv");
		words = new String[]{"soccer", "done", "super"};
		for(int i=0; i < words.length; i++) {
			int[] loc = getLocation(words[i]);
			if(loc != null) {
				if(loc[2] == 0) {
					System.out.println(words[i]+" found (Down) at row "+loc[0]+", column "+loc[1]);
				}
				else {
					System.out.println(words[i]+" found (Across) at row "+loc[0]+", column "+loc[1]);
				}
			}
			else {
				System.out.println(words[i]+" not found");
			}
		}
	}
}