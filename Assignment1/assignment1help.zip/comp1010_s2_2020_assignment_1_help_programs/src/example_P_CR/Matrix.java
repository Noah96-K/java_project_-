package example_P_CR;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Matrix {
	public static int[][] values;
	//number of rows: values.length
	//number of columns: values[0].length
	public static int rows = 0;
	public static int columns = 0;

	public static void read(String filename) throws FileNotFoundException {
		Scanner scanner = new Scanner(new FileReader(filename)); //not assessed
		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			String[] tokens = line.split(","); //tokens = {"1", "1", "2"}
			columns = tokens.length;
			rows++;
		}
		values = new int[rows][columns];
		scanner = new Scanner(new FileReader(filename));
		for(int i=0; i < rows; i++) {
			String line = scanner.nextLine();
			String[] tokens = line.split(",+");
			for(int k=0; k < tokens.length; k++) {
				values[i][k] = Integer.parseInt(tokens[k]);
			}
		}

		/**
		 * at this point of time, students can assume,
		 * data is in the array values
		 * 
		 * values[i][k] gives the number in row i, column k
		 */
	}

	public static void main(String[] args) throws FileNotFoundException {
		read("basic.csv");
		System.out.println("Sum of all numbers: "+sum());
		for(int i=0; i < rows; i++) {
			System.out.println("Sum of row "+i+": "+sumRow(i));
		}
		for(int k=0; k < columns; k++) {
			System.out.println("Sum of column "+k+": "+sumColumn(k));
		}
		
				//rows 0 and 2 are identical to row 8 (all contain 1,1,2)
				System.out.println("Number of rows identical to row 8: "+countRowsIdenticalTo(8));
	}

	public static int sum() {
		int total = 0;
		for(int curRow=0; curRow < rows; curRow++) {
			for(int curCol = 0; curCol < columns; curCol++) {
				total+=values[curRow][curCol];
			}
		}
		return total;
	}

	/**
	 * 
	 * @param row
	 * @return the sum of all values in the given row (first row is 0)
	 * return -1 if row number supplied is invalid
	 */
	public static int sumRow(int row) {
		if(row < 0 || row >= rows) {
			return -1; //ideally, we'd return null or throw an exception
		}

		//guaranteed that row is valid
		//values[row] is the sub-array containing all items in that row
		//for example: 	values[0] = {1,1,2}
		//				values[1] = {3,0,2}
		//				...

		int result = 0;
		for(int k=0; k < columns; k++) {
			result+=values[row][k];
		}
		return result;
	}

	public static int sumColumn(int column) {
		if(column < 0 || column >= columns) {
			return -1; //ideally, we'd return null or throw an exception
		}

		//guaranteed: column is a valid index

		int result = 0;
		for(int i=0; i < rows; i++) {
			result = result + values[i][column];
		}

		return result;
	}

	/**
	 * 
	 * @param row (index of a row)
	 * @return number of other rows that are 
	 * identical to the row with the index passed.
	 * return -1 if row is invalid
	 */
	public static int countRowsIdenticalTo(int row) {
		//BUGGY
		int count = 0;
		for(int curRow = 0; curRow < rows; curRow++) {
			boolean same = true;
			for(int curCol = 0; curCol < columns; curCol++) {
				if(values[row][curCol] != values[curRow][curCol]) {
					same = false;
				}
			}
			if(same == true) {
				count++; 
			}
		}
		return count;
	}
}















